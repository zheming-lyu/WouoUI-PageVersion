#ifndef __TEST_UI_H__
#define __TEST_UI_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "WouoUI.h"
void TestUI_Init(void);
extern WavePage wave_page;
#ifdef __cplusplus
}
#endif

#endif
